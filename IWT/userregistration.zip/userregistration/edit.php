<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Online Auction System</title>
	<link rel="stylesheet" type="text/css" href="styles/styles3.css">
	</head>
<body>

<?php 

    require_once("connection.php");
    $UserID = $_GET['GetID'];
    $query = " select * from usertable where name='".$UserID."'";
    $result = mysqli_query($con,$query);

    while($row=mysqli_fetch_assoc($result))
    {
        $UserName = $row['name'];
		$UserPassword = $row['password'];
    }

?>





<!--header and navigation bar-->
<div>
		<body>
			<img src="images/img1.png" alt="logo" class="logo">
			 <h2 class="sansserif">Quick Auctions</h2>
			 <h3 class="new3">The online Auction System</h3><br>
		 
			 <hr class="new4">
			 
	 
	 
		 <div class="topnav">
			 <a href="Home">Home</a>
			 <a href="Furniture.html">Categories</a>
			 <a href="#bidding">Bidding</a>
			 <a href="#about">About</a>
			 <a  href="Contact.html">Contact</a>
		 
				<div class="corner">
			 			<a href="Login.html">Login</a>
						 <a href="#Sign up">Logout</a>
				</div>

		</div>
</div>




               
			   
			   
			   
			   
			   
			   
			   
			   

<!--section2-->
<div class="side2">
	<div style="width:500px;height:500px;margin:0px auto;">
<br>
 <div class="container">
  <form action="update.php?ID=<?php echo $UserID ?>" method="post">
  <h3><center>Edit Data</center></h3>
  <div class="row">
    <div class="col-25">
      <label for="uname">User Name</label>
    </div>
    <div class="col-75">
      <input class="h1"type="text" id="uname" name="name" placeholder="Your User Name.." value="<?php echo $UserName ?>">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="email">Password</label>
    </div>
    <div class="col-75">
      <input class="h1" type="text" id="email" name="password" placeholder="email.."value="<?php echo $UserPassword?>">
    </div>
  </div>



  <div class="row">
    <input class="h2" type="submit" value="UPDATE" name="update">
	
  </div>
  </form>
</div>
</div>
</div>


<!--footer-->
<div class="side3">

<hr class="new4">

<img src="images/img5.png" alt="payment" class="payment">
<img src="images/img6.png" alt="SM" class="SM">


</div>
























</body>
</html>
