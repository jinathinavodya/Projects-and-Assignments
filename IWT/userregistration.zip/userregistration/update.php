<?php 

    require_once("connection.php");

    if(isset($_POST['update']))
    {
        
        $UserName = $_POST['name'];
        $UserPassword = $_POST['password'];
       
		

        $query = " update usertable set name = '".$UserName."', password='".$UserPassword."'";
        $result = mysqli_query($con,$query);

        if($result)
        {
            header("location:login.php");
        }
        else
        {
            echo ' Please Check Your Query ';
        }
    }
    else
    {
        header("location:home.php");
    }


?>