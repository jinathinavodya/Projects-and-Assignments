<?php

session_start ();
header('location:login.php');

$con=mysqli_connect('localhost','root',"","login");

mysqli_select_db($con,'login');

$name=$_POST['user'];
$country=$_POST['country'];
$province=$_POST['province'];
$city=$_POST['city'];
$address=$_POST['address'];
$postal=$_POST['postal'];
$contact=$_POST['contact'];
$pass=$_POST['password'];

$s="select*from usertable where name='$name'";

$result=mysqli_query($con,$s);

$num=mysqli_num_rows($result);

if($num==1){
	echo"Usename already taken";

}else{
	$reg="insert into usertable(name,User_Country,User_Province,User_City,User_Address,User_Postal,User_Contact,password)values('$name','$country','$province','$city','$address','$postal','$contact','$pass')";
	mysqli_query($con,$reg);
	echo"registration successful";
}

?>