<?php 

        require_once("connection.php ");

        if(isset($_GET['Del']))
        {
            $UserID = $_GET['Del'];
            $query = " delete from usertable where name = '".$UserID."'";
            $result = mysqli_query($con,$query);

            if($result)
            {
				echo'accout removed';
                header("location:login.php");
            }
            else
            {
                echo ' Please Check Your Query ';
            }
        }
        else
        {
            header("location:home.php");
        }

?>