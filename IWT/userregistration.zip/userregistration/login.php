<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Online Auction System</title>
	<link rel="stylesheet" type="text/css" href="styles/styles.css">
	</head>
<body>
<div>
		
			<img src="Images\img1.png" alt="logo" class="logo">
			 <h2 class="sansserif">Quick Auctions</h2>
			 <h3 class="new3">The online Auction System</h3><br>
		 
			 <hr class="new4">
			 
	 
	 
		
</div>



<br><br>
<div class="area1">
<div style="width:500px;height:500px;margin:0px auto;">
<div class="d">
  <form action="registration.php" method="post">
  <h3 align="left">Create New Account</h3>
  
  
    <label for="name"></label>
    <input class="h" type="text" id="fname" name="user" placeholder="Your name.." required>

   

	<label for="country"></label>
    <input class="h" type="text" id="country" name="country" placeholder="Country" required>
	
	
	<label for="province"></label>
    <input class="h" type="text" id="province" name="province" placeholder="Province" required>
	
	<label for="city"></label>
    <input class="h" type="text" id="city" name="city" placeholder="City">
	
	<label for="address"></label>
    <input class="h" type="text" id="address" name="address" placeholder="Address" required>
	
	<label for="pcode"></label>
    <input class="h" type="text" id="pcode" name="postal" placeholder="Postal Code" required>
	
	<label for="pnumber"></label>
    <input class="h" type="text" id="pnumber" name="contact" placeholder="Postal Number" required>
	
	<label for="crpass"></label>
    <input class="h" type="password" id="crpass" name="crpass" minlength="8" placeholder="Create Password" required>
	
	<label for="cpass"></label>
    <input class="h" type="password" id="cpass" name="password" minlength="8" placeholder="Confirm Password" required>
  
    <input class ="h1" type="submit" value="Register" >
  </form>
  
</div>
</div>
</div>
<div class="area2">
  <div style="width:500px;height:500px;margin:0px auto;">
  <div class="d">
  <form action="validation.php" method="post">
  <h3>Sign up</h3>
  
  
   
	<label for="uname"></label>
    <input class="h" type="text" id="uname" name="user" placeholder="User Name" required>
	<label for="pass"></label>
    <input class="h" type="password" id="cpass" name="password" maxlength="8" placeholder="Password" required>
	<input class="h1" type="submit" value="Login" name="submit">
	</form>
  </div>
  </div>
  </div>
  





<!--footer-->
<div class="side_c">

<hr class="new4">

<img src="Images/img5.png" alt="payment" class="payment">
<img src="Images/img6.png" alt="SM" class="SM">


</div>







