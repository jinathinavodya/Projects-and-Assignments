<?php
session_start();
$name=$_SESSION['username'];
if(!isset($_SESSION['username'])){
	header('location:login.php');
}
?>



<html>
<head>

	<title>Online Auction System</title>
	<link rel="stylesheet" type="text/css" href="styles/styles1.css">

</head>
<body>

<div>
		<body>
			<img src="Images\img1.png" alt="logo" class="logo">
			 <h2 class="sansserif">Quick Auctions</h2>
			 <h3 class="new3">The online Auction System</h3><br>
		 
			 <hr class="new4">
			 
	 
	 
		 <div class="topnav">
			 <a href="Home">Home</a>
			 <a href="Furniture.html">Categories</a>
			 <a href="bidding.html">Bidding</a>
			 <a href="#about">About</a>
			 <a  href="Contact.html">Contact</a>
		 
				<div class="corner">
			 			<a href="Login.html">Login</a>
						 <a class="active" href="#Sign up">Logout</a>
				</div>

		</div>
</div>




















<div class="home">
<div class="containerhome">




<div class="displayname">
<h2 class="v1" text-align="center"> welcome <?php echo $_SESSION['username'];?></h2>
</div>

<div class="options">
<div class="opalign">
<a href="logout.php"><button class="homebutton button1">LOGOUT</button></a>
<a href="delete.php?Del=<?php echo $name ?>"><button class="homebutton button2">DELETE</button></a>
<a href="edit.php?GetID=<?php echo $name ?>"><button class="homebutton button3">EDIT</button></a>
</div>
</div>







</div>
</div>

<!--footer-->
<div class="side_c">

<hr class="new4">

<img src="Images/img5.png" alt="payment" class="payment">
<img src="Images/img6.png" alt="SM" class="SM">


</div>



</body>
</html>

