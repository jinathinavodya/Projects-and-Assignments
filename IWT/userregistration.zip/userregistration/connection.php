<?php
$con=mysqli_connect("localhost","root","","login");

if(!$con)
{
    die("connection error");
}
?>